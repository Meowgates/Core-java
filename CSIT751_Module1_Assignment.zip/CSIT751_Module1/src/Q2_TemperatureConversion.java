import java.util.Scanner;

/*
 * Q2. Data Type Conversion
 * Stores an integer Celsius temperature, converts it to Fahrenheit
 * using F = (C * 9/5) + 32, and displays both values.
 */
public class Q2_TemperatureConversion {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter temperature in Celsius: ");
        int celsius = sc.nextInt();

        double fahrenheit = (celsius * 9.0 / 5) + 32;

        System.out.println("Temperature in Celsius    : " + celsius);
        System.out.println("Temperature in Fahrenheit : " + fahrenheit);

        sc.close();
    }
}
