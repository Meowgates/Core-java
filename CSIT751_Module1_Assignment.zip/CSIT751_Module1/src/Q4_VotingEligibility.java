import java.util.Scanner;

/*
 * Q4. Logical Operators - Eligibility Check
 * Checks if a person is eligible to vote based on age (>= 18)
 * and citizenship status, using logical operators (&&, ||).
 */
public class Q4_VotingEligibility {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter age: ");
        int age = sc.nextInt();

        System.out.print("Is citizen? (true/false): ");
        boolean isCitizen = sc.nextBoolean();

        boolean isEligible = (age >= 18) && isCitizen;

        // Example of an OR based scenario (informational message)
        boolean needsMoreInfo = (age < 18) || (!isCitizen);

        if (isEligible) {
            System.out.println("Result: Eligible to vote.");
        } else {
            System.out.println("Result: Not eligible to vote.");
            if (needsMoreInfo) {
                if (age < 18) {
                    System.out.println("Reason: Age is below 18.");
                }
                if (!isCitizen) {
                    System.out.println("Reason: Not a citizen.");
                }
            }
        }

        sc.close();
    }
}
