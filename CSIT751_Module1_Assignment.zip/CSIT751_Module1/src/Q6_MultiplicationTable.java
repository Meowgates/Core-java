import java.util.Scanner;

/*
 * Q6. Loop - Multiplication Table
 * Prints the multiplication table of a user-given number
 * from 1 to 10 using a for loop.
 */
public class Q6_MultiplicationTable {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int number = sc.nextInt();

        System.out.println("\nMultiplication table of " + number + ":");
        for (int i = 1; i <= 10; i++) {
            System.out.println(number + " x " + i + " = " + (number * i));
        }

        sc.close();
    }
}
