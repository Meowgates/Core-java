import java.util.Scanner;

/*
 * Q3. Arithmetic Operations
 * Accepts two integers and performs addition, subtraction,
 * multiplication, division, and modulus.
 */
public class Q3_ArithmeticOperations {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter first integer: ");
        int a = sc.nextInt();

        System.out.print("Enter second integer: ");
        int b = sc.nextInt();

        System.out.println("\n----- Results -----");
        System.out.println("Addition       : " + (a + b));
        System.out.println("Subtraction    : " + (a - b));
        System.out.println("Multiplication : " + (a * b));

        if (b != 0) {
            System.out.println("Division       : " + (a / b));
            System.out.println("Modulus        : " + (a % b));
        } else {
            System.out.println("Division       : undefined (division by zero)");
            System.out.println("Modulus        : undefined (division by zero)");
        }

        sc.close();
    }
}
