# CSIT751 (Core Java) — Module I: Introduction to Java
### Practical Home Assignment 1

This repository contains solutions to the 10 programming exercises from
**Module I – Introduction to Java (Practical Home Assignment 1)**.

## 📂 Structure

```
CSIT751_Module1/
├── README.md
└── src/
    ├── Q1_IdentifierNaming.java
    ├── Q2_TemperatureConversion.java
    ├── Q3_ArithmeticOperations.java
    ├── Q4_VotingEligibility.java
    ├── Q5_SimpleCalculator.java
    ├── Q6_MultiplicationTable.java
    ├── Q7_SumOfEvenNumbers.java
    ├── Q8_StudentMarksArray.java
    ├── Q9_FindMaximum.java
    └── Q10_AverageAndGrade.java
```

## 📋 Exercises Covered

| # | File | Topic |
|---|------|-------|
| 1 | `Q1_IdentifierNaming.java` | Identifier naming practice — student name, roll number, marks |
| 2 | `Q2_TemperatureConversion.java` | Data type conversion — Celsius to Fahrenheit |
| 3 | `Q3_ArithmeticOperations.java` | Arithmetic operations — +, -, *, /, % |
| 4 | `Q4_VotingEligibility.java` | Logical operators — voting eligibility check |
| 5 | `Q5_SimpleCalculator.java` | Control statements — simple calculator with if-else |
| 6 | `Q6_MultiplicationTable.java` | Loops — multiplication table using `for` |
| 7 | `Q7_SumOfEvenNumbers.java` | Loops with conditionals — sum of even numbers (1–50) using `while` |
| 8 | `Q8_StudentMarksArray.java` | Arrays — store and print marks of 5 students |
| 9 | `Q9_FindMaximum.java` | Arrays and loops — find maximum of 10 integers |
| 10 | `Q10_AverageAndGrade.java` | Mini project — average marks and grade assignment |

## ▶️ How to Compile and Run

Each file is a standalone Java program with its own `main` method. From the
`src` folder:

```bash
# Compile a single file
javac Q1_IdentifierNaming.java

# Run it
java Q1_IdentifierNaming
```

To compile everything at once:

```bash
cd src
javac *.java
```

Then run any class individually, e.g. `java Q6_MultiplicationTable`.

Most programs use `Scanner` to read input from the console, so run them
in a terminal (not just an IDE "Run" button without a console) and enter
values when prompted.

## 🛠️ Requirements
- JDK 8 or later
- Any IDE (IntelliJ IDEA, Eclipse, VS Code) or plain command line

## 👤 Author
Submitted as part of CSIT751 (Core Java) — Practical Home Assignment 1.
